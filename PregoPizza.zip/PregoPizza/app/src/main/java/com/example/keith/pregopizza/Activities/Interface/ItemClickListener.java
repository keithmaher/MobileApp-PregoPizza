package com.example.keith.pregopizza.Activities.Interface;

import android.view.View;

/**
 * Created by Keith on 13/03/2018.
 */

public interface ItemClickListener {
    void onClick(View view, int position, boolean isLongClick);
}
